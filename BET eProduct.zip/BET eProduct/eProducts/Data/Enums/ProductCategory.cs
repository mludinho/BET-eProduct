﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eProducts.Data
{
    public enum ProductCategory
    {
        Sports = 1,
        Grocery,
        Outdoor,
        Cars,
        Education,
        FreshStop
    }
}
